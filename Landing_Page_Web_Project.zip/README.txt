Landing Page Web Development Project

Files:
- index.html
- style.css
- script.js

How to run:
1. Extract ZIP
2. Open index.html in your browser

Features:
- Responsive modern landing page
- Hero section
- Features section
- Pricing section
- Contact form
- Smooth scroll
- Simple JavaScript interaction

You can:
- Change colors, text, company name
- Add images
- Use this as portfolio project
