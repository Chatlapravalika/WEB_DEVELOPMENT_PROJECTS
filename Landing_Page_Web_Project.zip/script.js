function scrollToSection() {
  document.getElementById("features").scrollIntoView({ behavior: "smooth" });
}

function submitForm() {
  document.getElementById("msg").innerText = "✅ Message sent successfully!";
  return false;
}
