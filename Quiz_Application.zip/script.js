const quiz = [
    {q: "What is HTML?", a: ["Language", "Markup", "Protocol"], c: 1},
    {q: "What is CSS used for?", a: ["Styling", "Logic", "Database"], c: 0},
    {q: "JavaScript is?", a: ["Backend", "Frontend", "Both"], c: 2}
];

let index = 0;
let score = 0;

function loadQuestion() {
    document.getElementById("question").innerText = quiz[index].q;
    let options = "";
    quiz[index].a.forEach((opt, i) => {
        options += `<button onclick="check(${i})">${opt}</button><br>`;
    });
    document.getElementById("options").innerHTML = options;
}

function check(ans) {
    if (ans === quiz[index].c) score++;
}

function nextQuestion() {
    index++;
    if (index < quiz.length) {
        loadQuestion();
    } else {
        document.getElementById("quiz-container");
        document.getElementById("score").innerText = "Your Score: " + score;
    }
}

loadQuestion();
