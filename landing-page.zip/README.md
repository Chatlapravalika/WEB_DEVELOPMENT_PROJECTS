# Landing Page Project

A simple landing page built using HTML and CSS.
Perfect for beginners to practice layout, styling,
and basic responsive design.

## Tech Stack
- HTML
- CSS
