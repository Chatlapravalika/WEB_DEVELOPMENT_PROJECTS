Restaurant Website built using HTML and CSS.
Beginner-friendly project with menu and contact details.
