# 📚 Library Management Web Application

A beautiful, modern frontend-only Library Management System built with HTML, CSS, and JavaScript. This application provides a complete digital library experience with user authentication, book browsing, and interactive features.

## ✨ Features

### 🔐 Authentication System
- **Login Page**: Secure login with email and password
- **Session Management**: Username stored in localStorage
- **Auto-redirect**: Unauthorized users redirected to login
- **Logout Functionality**: Clear session and redirect to login

### 📖 Book Management
- **All Books Page**: Browse complete book collection
- **Categories Page**: Books organized by subject (Aptitude, Reasoning, History, Economy)
- **Search Functionality**: Real-time search by title or author
- **PDF Access**: Direct links to open books in new tabs

### 👥 User Features
- **Membership Registration**: Join the library community
- **Contact Form**: Get in touch with support
- **Responsive Design**: Works on all devices
- **Modern UI**: Beautiful gradient backgrounds and animations

## 🚀 Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- No server required - runs entirely in the browser

### Installation
1. Download or clone all files to your local machine
2. Ensure the folder structure is maintained:
   ```
   library-management/
   ├── index.html
   ├── login.html
   ├── books.html
   ├── categories.html
   ├── membership.html
   ├── contact.html
   ├── style.css
   ├── script.js
   └── books/
       ├── quantitative-aptitude.pdf
       ├── fast-track-arithmetic.pdf
       ├── logical-reasoning.pdf
       ├── analytical-reasoning.pdf
       ├── indian-history.pdf
       ├── modern-india.pdf
       ├── indian-economy.pdf
       └── economy-civil-services.pdf
   ```

### Running the Application
1. Open `login.html` in your web browser
2. Enter any email and password to login
3. Explore the library features!

## 📱 Pages Overview

### 🔑 Login Page (`login.html`)
- Email and password fields
- Form validation
- "Register here" link to membership page
- Beautiful gradient background

### 🏠 Home Page (`index.html`)
- Welcome message and library statistics
- Feature highlights
- Navigation to all sections
- User profile display

### 📚 Books Page (`books.html`)
- Complete book collection
- Search functionality
- Book cards with "Read Book" buttons
- Direct PDF access

### 🗂️ Categories Page (`categories.html`)
- Books organized by category:
  - **Aptitude**: Quantitative and arithmetic books
  - **Reasoning**: Logical and analytical reasoning
  - **History**: Indian history and modern India
  - **Economy**: Indian economy and civil services
- Category-specific book displays

### 👤 Membership Page (`membership.html`)
- Registration form with validation
- Interest selection checkboxes
- Success confirmation
- Professional form design

### 📞 Contact Page (`contact.html`)
- Contact information display
- Message form with validation
- Multiple contact methods
- Responsive layout

## 🎨 Design Features

### Visual Design
- **Gradient Backgrounds**: Beautiful purple-blue gradients
- **Glass Morphism**: Frosted glass effects with backdrop blur
- **Modern Typography**: Poppins font family
- **Smooth Animations**: Hover effects and transitions
- **Card-based Layout**: Clean, organized content presentation

### Color Scheme
- **Primary**: Purple to blue gradient (#667eea to #764ba2)
- **Accent**: Gold highlights (#ffd700)
- **Text**: Dark gray (#333) on light backgrounds
- **Success**: Green (#4CAF50)
- **Error**: Red (#f44336)

### Interactive Elements
- **Hover Effects**: Cards lift and scale on hover
- **Button Animations**: Click feedback and loading states
- **Smooth Scrolling**: Elegant page transitions
- **Form Validation**: Real-time input validation
- **Search**: Instant filtering of book results

## 🔧 Technical Details

### Technologies Used
- **HTML5**: Semantic markup and structure
- **CSS3**: Modern styling with flexbox and grid
- **JavaScript (ES6+)**: Vanilla JS with modern features
- **Font Awesome**: Icon library
- **Google Fonts**: Poppins typography

### Browser Compatibility
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

### Responsive Breakpoints
- **Desktop**: 1200px and above
- **Tablet**: 768px - 1199px
- **Mobile**: Below 768px

## 📖 Book Collection

The library includes competitive exam books across four main categories:

### Aptitude
- Quantitative Aptitude by R.S. Aggarwal
- Fast Track Objective Arithmetic by Rajesh Verma

### Reasoning
- A Modern Approach to Logical Reasoning by R.S. Aggarwal
- Analytical Reasoning by M.K. Pandey

### History
- Indian History by Krishna Reddy
- History of Modern India by Bipan Chandra

### Economy
- Indian Economy by Ramesh Singh
- Economy for Civil Services by Nitin Singhania

## 🚀 Future Enhancements

- User dashboard with reading history
- Book ratings and reviews
- Advanced search filters
- Bookmark functionality
- Reading progress tracking
- Admin panel for book management

## 📝 Usage Notes

1. **Login**: Use any valid email format (e.g., `user@example.com`)
2. **PDFs**: Sample PDFs are included - replace with actual book files
3. **Customization**: Modify `booksData` in `script.js` to add/remove books
4. **Styling**: Update CSS variables in `style.css` for theme changes

## 🤝 Contributing

This is a frontend-only application. To contribute:
1. Fork the repository
2. Make your changes
3. Test across different browsers
4. Submit a pull request

## 📄 License

This project is open source and available under the MIT License.

---

**Enjoy exploring your digital library! 📚✨**
