Write-Host "Starting Library Management System..." -ForegroundColor Green
Write-Host ""

# Start the server in background
Write-Host "Starting server on port 3000..." -ForegroundColor Yellow
Start-Process -FilePath "node" -ArgumentList "server.js" -WindowStyle Hidden

# Wait for server to start
Start-Sleep -Seconds 3

# Open login page
Write-Host "Opening login page..." -ForegroundColor Cyan
Start-Process "http://localhost:3000/login"

# Wait for user interaction
Write-Host ""
Write-Host "Please login with any email and password" -ForegroundColor White
Write-Host "After login, the home page will open automatically" -ForegroundColor White
Write-Host ""

$null = $null

Write-Host ""
Write-Host "Library Management System is running!" -ForegroundColor Green
Write-Host "Login Page: http://localhost:3000/login" -ForegroundColor Blue
Write-Host "(Home opens after successful login)" -ForegroundColor DarkGray
Write-Host "Books Page: http://localhost:3000/books" -ForegroundColor Blue
Write-Host "Categories Page: http://localhost:3000/categories" -ForegroundColor Blue
Write-Host "Membership Page: http://localhost:3000/membership" -ForegroundColor Blue
Write-Host "Contact Page: http://localhost:3000/contact" -ForegroundColor Blue
Write-Host ""
Write-Host "Press any key to stop the server..." -ForegroundColor Red
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

# Stop the server
Write-Host "Stopping server..." -ForegroundColor Yellow
Get-Process -Name "node" -ErrorAction SilentlyContinue | Stop-Process -Force
Write-Host "Server stopped." -ForegroundColor Green
