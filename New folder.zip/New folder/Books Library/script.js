// Library Management System JavaScript

// Book data
const booksData = {
    aptitude: [
        {
            title: "Quantitative Aptitude",
            author: "R.S. Aggarwal",
            pdf: "books/quantitative-aptitude.pdf",
            category: "aptitude"
        },
        {
            title: "Fast Track Objective Arithmetic",
            author: "Rajesh Verma",
            pdf: "books/fast-track-arithmetic.pdf",
            category: "aptitude"
        }
    ],
    reasoning: [
        {
            title: "A Modern Approach to Logical Reasoning",
            author: "R.S. Aggarwal",
            pdf: "books/logical-reasoning.pdf",
            category: "reasoning"
        },
        {
            title: "Analytical Reasoning",
            author: "M.K. Pandey",
            pdf: "books/analytical-reasoning.pdf",
            category: "reasoning"
        }
    ],
    history: [
        {
            title: "Indian History",
            author: "Krishna Reddy",
            pdf: "books/indian-history.pdf",
            category: "history"
        },
        {
            title: "History of Modern India",
            author: "Bipan Chandra",
            pdf: "books/modern-india.pdf",
            category: "history"
        }
    ],
    economy: [
        {
            title: "Indian Economy",
            author: "Ramesh Singh",
            pdf: "books/indian-economy.pdf",
            category: "economy"
        },
        {
            title: "Economy for Civil Services",
            author: "Nitin Singhania",
            pdf: "books/economy-civil-services.pdf",
            category: "economy"
        }
    ]
};

// Get all books
function getAllBooks() {
    return Object.values(booksData).flat();
}

// Check if user is logged in
function checkAuth() {
    const username = localStorage.getItem('username');
    const currentPage = window.location.pathname.split('/').pop();
    
    if (!username) {
        // Only redirect to login if not already on login page
        if (currentPage !== 'login.html' && currentPage !== 'demo.html') {
            window.location.href = 'login.html';
            return false;
        }
        return false;
    }
    return true;
}

// Display username in profile section
function displayUsername() {
    const username = localStorage.getItem('username');
    if (username) {
        const usernameElements = document.querySelectorAll('#username');
        usernameElements.forEach(element => {
            element.textContent = username;
        });
        
        // Also update the profile section visibility
        const profileSection = document.getElementById('profileSection');
        if (profileSection) {
            profileSection.style.display = 'flex';
        }
    } else {
        // Hide profile section if no user is logged in
        const profileSection = document.getElementById('profileSection');
        if (profileSection) {
            profileSection.style.display = 'none';
        }
    }
}

// Login functionality
function handleLogin() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        console.log('Login form found, adding event listener');
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Login form submitted');
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            console.log('Email:', email, 'Password:', password ? '***' : 'empty');
            
            // Simple validation
            if (!email || !password) {
                alert('Please fill in all fields');
                return;
            }
            
            // Extract username from email
            const username = email.split('@')[0];
            console.log('Username extracted:', username);
            
            // Save username to localStorage
            localStorage.setItem('username', username);
            console.log('Username saved to localStorage');
            
            // Show success message
            alert('Login successful! Redirecting to home page...');
            
            // Redirect to home page
            setTimeout(() => {
                console.log('Redirecting to demo.html');
                try {
                    window.location.href = 'demo.html';
                } catch (error) {
                    console.error('Redirect failed:', error);
                    // Fallback redirect
                    window.location.replace('demo.html');
                }
            }, 1500);
        });
    } else {
        console.log('Login form not found');
    }
}

// Logout functionality
function handleLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Clear localStorage
            localStorage.removeItem('username');
            
            // Show logout message
            alert('You have been logged out successfully.');
            
            // Redirect to login page
            window.location.href = 'login.html';
        });
    }
}

// Create book card HTML
function createBookCard(book) {
    return `
        <div class="book-card fade-in">
            <h3>${book.title}</h3>
            <p>by ${book.author}</p>
            <a href="${book.pdf}" target="_blank" class="read-btn">
                <i class="fas fa-book-open"></i>
                Read Book
            </a>
        </div>
    `;
}

// Load books for a specific category
function loadBooksForCategory(categoryId, books) {
    const container = document.getElementById(categoryId);
    if (container) {
        container.innerHTML = books.map(book => createBookCard(book)).join('');
    }
}

// Load all books on books page
function loadAllBooks() {
    const booksGrid = document.getElementById('booksGrid');
    if (booksGrid) {
        const allBooks = getAllBooks();
        booksGrid.innerHTML = allBooks.map(book => createBookCard(book)).join('');
    }
}

// Search functionality
function handleSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const allBooks = getAllBooks();
            const filteredBooks = allBooks.filter(book => 
                book.title.toLowerCase().includes(searchTerm) || 
                book.author.toLowerCase().includes(searchTerm)
            );
            
            const booksGrid = document.getElementById('booksGrid');
            if (booksGrid) {
                booksGrid.innerHTML = filteredBooks.map(book => createBookCard(book)).join('');
            }
        });
    }
}

// Load books by category on categories page
function loadBooksByCategory() {
    Object.keys(booksData).forEach(category => {
        const categoryId = category + 'Books';
        loadBooksForCategory(categoryId, booksData[category]);
    });
}

// Membership form handling
function handleMembershipForm() {
    const membershipForm = document.getElementById('membershipForm');
    if (membershipForm) {
        membershipForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const name = formData.get('name');
            const email = formData.get('email');
            const phone = formData.get('phone');
            const address = formData.get('address');
            
            // Simple validation
            if (!name || !email || !phone || !address) {
                alert('Please fill in all required fields');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address');
                return;
            }
            
            // Phone validation
            const phoneRegex = /^[\d\s\-\+\(\)]+$/;
            if (!phoneRegex.test(phone)) {
                alert('Please enter a valid phone number');
                return;
            }
            
            // Show success message
            alert('Registration Successful! Welcome to our library community.');
            
            // Reset form
            this.reset();
        });
    }
}

// Contact form handling
function handleContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const name = formData.get('name');
            const email = formData.get('email');
            const message = formData.get('message');
            
            // Validation
            if (!name || !email || !message) {
                alert('Please fill in all required fields');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address');
                return;
            }
            
            // Show success message
            alert('Message Sent Successfully! We will get back to you soon.');
            
            // Reset form
            this.reset();
        });
    }
}

// Set active navigation link
function setActiveNavLink() {
    const currentPage = window.location.pathname.split('/').pop();
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });
}

// Add smooth scrolling
function addSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Add loading animation to buttons
function addLoadingAnimation() {
    const buttons = document.querySelectorAll('button[type="submit"]');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const originalText = this.innerHTML;
            this.innerHTML = '<span class="loading"></span> Processing...';
            this.disabled = true;
            
            // Re-enable after 2 seconds (simulate processing)
            setTimeout(() => {
                this.innerHTML = originalText;
                this.disabled = false;
            }, 2000);
        });
    });
}

// Initialize page based on current location
function initializePage() {
    const currentPage = window.location.pathname.split('/').pop();
    
    // Check authentication for all pages except login and demo
    if (currentPage !== 'login.html' && currentPage !== 'demo.html') {
        if (!checkAuth()) {
            return;
        }
    }
    
    // Display username if logged in
    displayUsername();
    
    // Set active navigation
    setActiveNavLink();
    
    // Add smooth scrolling
    addSmoothScrolling();
    
    // Add loading animations
    addLoadingAnimation();
    
    // Page-specific initialization
    switch (currentPage) {
        case 'login.html':
            handleLogin();
            break;
        case 'index.html':
            // Home page - no additional setup needed
            break;
        case 'books.html':
            loadAllBooks();
            handleSearch();
            break;
        case 'categories.html':
            loadBooksByCategory();
            break;
        case 'membership.html':
            handleMembershipForm();
            break;
        case 'contact.html':
            handleContactForm();
            break;
    }
    
    // Add logout functionality to all pages
    handleLogout();
}

// Add some interactive effects
function addInteractiveEffects() {
    // Add hover effects to cards
    const cards = document.querySelectorAll('.book-card, .feature-card, .info-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Add click effects to buttons
    const buttons = document.querySelectorAll('.read-btn, .submit-btn, .login-btn');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });
}

// Add keyboard navigation
function addKeyboardNavigation() {
    document.addEventListener('keydown', function(e) {
        // Escape key to clear search
        if (e.key === 'Escape') {
            const searchInput = document.getElementById('searchInput');
            if (searchInput && document.activeElement === searchInput) {
                searchInput.value = '';
                searchInput.dispatchEvent(new Event('input'));
            }
        }
        
        // Enter key to submit forms
        if (e.key === 'Enter') {
            const activeElement = document.activeElement;
            if (activeElement && activeElement.tagName === 'INPUT' && activeElement.type !== 'submit') {
                const form = activeElement.closest('form');
                if (form) {
                    const submitButton = form.querySelector('button[type="submit"]');
                    if (submitButton) {
                        submitButton.click();
                    }
                }
            }
        }
    });
}

// Add scroll animations
function addScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);
    
    // Observe all cards and sections
    const elementsToAnimate = document.querySelectorAll('.book-card, .feature-card, .info-card, .category-section');
    elementsToAnimate.forEach(element => {
        observer.observe(element);
    });
}

// Test login function for debugging
function testLogin() {
    console.log('Test login triggered');
    localStorage.setItem('username', 'Test User');
    alert('Test login successful! Redirecting...');
    setTimeout(() => {
        window.location.href = 'demo.html';
    }, 1000);
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializePage();
    addInteractiveEffects();
    addKeyboardNavigation();
    addScrollAnimations();
});

// Handle page visibility change (for better UX)
document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
        // Page became visible, refresh username display
        displayUsername();
    }
});

// Add error handling for PDF links
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('read-btn') || e.target.closest('.read-btn')) {
        const link = e.target.closest('.read-btn');
        if (link) {
            // Add a small delay to show the click effect
            setTimeout(() => {
                // Check if PDF exists (basic check)
                const pdfPath = link.getAttribute('href');
                if (pdfPath && pdfPath.includes('.pdf')) {
                    // Try to open the PDF
                    try {
                        window.open(pdfPath, '_blank');
                    } catch (error) {
                        alert('Sorry, the PDF file is not available at the moment. Please try again later.');
                    }
                }
            }, 200);
        }
    }
});

// Add a simple notification system
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#4CAF50' : '#f44336'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 500;
        animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Add CSS for notifications
const notificationStyles = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;

// Inject notification styles
const styleSheet = document.createElement('style');
styleSheet.textContent = notificationStyles;
document.head.appendChild(styleSheet);
