const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the current directory
app.use(express.static('.'));

// Route for the main home page (index.html)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Route for home page (same as demo.html)
app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'demo.html'));
});

// Route for login page
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// Route for books page
app.get('/books', (req, res) => {
    res.sendFile(path.join(__dirname, 'books.html'));
});

// Route for categories page
app.get('/categories', (req, res) => {
    res.sendFile(path.join(__dirname, 'categories.html'));
});

// Route for membership page
app.get('/membership', (req, res) => {
    res.sendFile(path.join(__dirname, 'membership.html'));
});

// Route for contact page
app.get('/contact', (req, res) => {
    res.sendFile(path.join(__dirname, 'contact.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`🚀 Library Management System is running!`);
    console.log(`📚 Demo Page: http://localhost:${PORT}`);
    console.log(`🔑 Login Page: http://localhost:${PORT}/login`);
    console.log(`🏠 Home Page: http://localhost:${PORT}/home`);
    console.log(`📖 Books Page: http://localhost:${PORT}/books`);
    console.log(`🗂️ Categories Page: http://localhost:${PORT}/categories`);
    console.log(`👤 Membership Page: http://localhost:${PORT}/membership`);
    console.log(`📞 Contact Page: http://localhost:${PORT}/contact`);
    console.log(`\n✨ All pages are accessible!`);
    console.log(`\nPress Ctrl+C to stop the server`);
});

// Handle 404 errors
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, 'demo.html'));
});
