const api = '/api/students';

async function fetchStudents() {
  const res = await fetch(api);
  const data = await res.json();
  return data;
}

function renderTable(students) {
  const tbody = document.querySelector('#students-table tbody');
  tbody.innerHTML = '';
  students.forEach(s => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${s.student_id}</td>
      <td>${s.first_name} ${s.last_name}</td>
      <td>${s.email || ''}</td>
      <td>${s.department || ''}</td>
      <td>${s.year || ''}</td>
      <td class="actions">
        <button onclick="editStudent(${s.student_id})">Edit</button>
        <button onclick="deleteStudent(${s.student_id})">Delete</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

async function loadAndRender() {
  const students = await fetchStudents();
  renderTable(students);
}

document.getElementById('student-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('student_id').value;
  const payload = {
    first_name: document.getElementById('first_name').value,
    last_name: document.getElementById('last_name').value,
    email: document.getElementById('email').value,
    department: document.getElementById('department').value,
    year: parseInt(document.getElementById('year').value) || null
  };
  if (id) {
    await fetch(api + '/' + id, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  } else {
    await fetch(api, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  }
  document.getElementById('student-form').reset();
  document.getElementById('student_id').value = '';
  loadAndRender();
});

document.getElementById('clear-btn').addEventListener('click', () => {
  document.getElementById('student-form').reset();
  document.getElementById('student_id').value = '';
});

window.editStudent = async function(id) {
  const res = await fetch(api + '/' + id);
  if (!res.ok) return alert('Student not found');
  const s = await res.json();
  document.getElementById('student_id').value = s.student_id;
  document.getElementById('first_name').value = s.first_name;
  document.getElementById('last_name').value = s.last_name;
  document.getElementById('email').value = s.email || '';
  document.getElementById('department').value = s.department || '';
  document.getElementById('year').value = s.year || '';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

window.deleteStudent = async function(id) {
  if (!confirm('Delete student ID ' + id + '?')) return;
  await fetch(api + '/' + id, { method: 'DELETE' });
  loadAndRender();
}

document.getElementById('search').addEventListener('input', async (e) => {
  const q = e.target.value.toLowerCase();
  const students = await fetchStudents();
  const filtered = students.filter(s => (s.first_name + ' ' + s.last_name + ' ' + (s.department||'')).toLowerCase().includes(q));
  renderTable(filtered);
});

// initial load
loadAndRender();
