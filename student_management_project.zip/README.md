# Student Management App (Beginner Full-Stack)

This is a beginner-friendly full-stack Student Management application built with **Node.js (Express)** and **SQLite**. It includes a simple frontend (HTML/CSS/JS) and backend APIs for CRUD operations on students.

## Features
- Add, update, delete, and list students
- Simple search by name/department
- Uses SQLite database `students.db` created automatically
- Serves a static frontend from `/public`

## Quick Start (requires Node.js)
1. Download the project and open a terminal in the project folder.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the server:
   ```bash
   npm start
   ```
4. Open a browser and go to `http://localhost:3000`

## Files
- `server.js` - Express server and API routes
- `package.json` - Node project configuration
- `public/` - Frontend files (index.html, style.css, app.js)
- `students.db` - SQLite DB (created on first run)
- `README.md` - this file

## Notes
- This is for learning purposes. For production, add input validation, authentication, and better error handling.
- To reset sample data, delete `students.db` and restart the server.
