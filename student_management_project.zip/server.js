const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');

const app = express();
const DB_PATH = path.join(__dirname, 'students.db');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Initialize SQLite DB
const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) return console.error('DB open error:', err.message);
  console.log('Connected to SQLite database.');
});

// Create table if not exists and seed sample data
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE,
    department TEXT,
    year INTEGER
  )`);

  // Insert sample rows if table empty
  db.get("SELECT COUNT(*) AS cnt FROM students", (err, row) => {
    if (err) return console.error(err.message);
    if (row.cnt === 0) {
      const stmt = db.prepare("INSERT INTO students(first_name, last_name, email, department, year) VALUES(?,?,?,?,?)");
      const sample = [
        ['Priya','Nair','priya.nair@student.edu','Computer Science',3],
        ['Arjun','Patel','arjun.patel@student.edu','Computer Science',4],
        ['Sana','Khan','sana.khan@student.edu','Electronics',2],
      ];
      sample.forEach(r => stmt.run(r));
      stmt.finalize();
      console.log('Inserted sample students.');
    }
  });
});

// Routes
app.get('/api/students', (req, res) => {
  db.all("SELECT * FROM students ORDER BY student_id", (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.get('/api/students/:id', (req, res) => {
  const id = req.params.id;
  db.get("SELECT * FROM students WHERE student_id = ?", [id], (err, row) => {
    if (err) return res.status(500).json({error: err.message});
    if (!row) return res.status(404).json({error: 'Student not found'});
    res.json(row);
  });
});

app.post('/api/students', (req, res) => {
  const { first_name, last_name, email, department, year } = req.body;
  const sql = "INSERT INTO students(first_name, last_name, email, department, year) VALUES(?,?,?,?,?)";
  db.run(sql, [first_name, last_name, email, department, year], function(err) {
    if (err) return res.status(400).json({error: err.message});
    res.json({student_id: this.lastID});
  });
});

app.put('/api/students/:id', (req, res) => {
  const id = req.params.id;
  const { first_name, last_name, email, department, year } = req.body;
  const sql = `UPDATE students SET first_name=?, last_name=?, email=?, department=?, year=? WHERE student_id=?`;
  db.run(sql, [first_name, last_name, email, department, year, id], function(err) {
    if (err) return res.status(400).json({error: err.message});
    if (this.changes === 0) return res.status(404).json({error: 'Student not found'});
    res.json({updated: true});
  });
});

app.delete('/api/students/:id', (req, res) => {
  const id = req.params.id;
  db.run("DELETE FROM students WHERE student_id = ?", [id], function(err) {
    if (err) return res.status(400).json({error: err.message});
    if (this.changes === 0) return res.status(404).json({error: 'Student not found'});
    res.json({deleted: true});
  });
});

// Serve frontend index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
